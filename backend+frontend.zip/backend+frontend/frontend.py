# frontend.py
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
from PIL import Image, ImageDraw, ImageFont, ImageTk
import threading
import cv2
import os


try:
    from backend import BackendProcessor, OUTPUT_FILE
except ImportError:
    print("Warning: backend.py not found. Some features may not work.")


    # Create a dummy backend for UI testing
    class BackendProcessor:
        def __init__(self):
            self.mode = "word"
            self.probs_ema = None
            self.cap = None

        def initialize_camera(self):
            return False

        def release_camera(self):
            pass

        def set_mode(self, mode):
            self.mode = mode

        def process_frame(self, frame):
            return None, "Backend not loaded", 0.0, [], "No detection"

        def get_camera_frame(self):
            return False, None

        def clean_word(self, word):
            return word

        def generate_sign_video(self, text, progress_callback=None):
            return False, ["Backend not available"], None

        def get_available_words(self):
            return ["খারাপ", "সুন্দর", "ভালো", "আমাকে", "আমার", "তুমি", "সালাম"]

        def check_video_file(self, filepath):
            return False

        def get_video_capture(self, filepath):
            return None


    OUTPUT_FILE = "output.mp4"


class LandingPage:
    def __init__(self, root, backend):
        self.root = root
        self.backend = backend
        self.root.title("ISHARAY - Bridging Voices and Signs in Bangla")
        self.root.geometry("1200x800")
        self.root.configure(bg="#1a1a2e")

        self.setup_landing_page()

    def setup_landing_page(self):
        # Main container
        main_frame = tk.Frame(self.root, bg="#1a1a2e")
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)

        # Header
        header_frame = tk.Frame(main_frame, bg="#1a1a2e")
        header_frame.pack(fill="x", pady=(0, 20))

        # Welcome text
        welcome_label = tk.Label(header_frame,
                                 text="WELCOME TO",
                                 font=("Arial", 24, "bold"),
                                 bg="#1a1a2e",
                                 fg="#e6e6e6")
        welcome_label.pack(pady=(10, 0))

        # App name
        app_name_label = tk.Label(header_frame,
                                  text="ISHARAY",
                                  font=("Arial", 48, "bold"),
                                  bg="#1a1a2e",
                                  fg="#4cc9f0")
        app_name_label.pack(pady=(0, 10))

        # Tagline
        tagline_label = tk.Label(header_frame,
                                 text="BRIDGING VOICES AND SIGNS IN BANGLA",
                                 font=("Arial", 16),
                                 bg="#1a1a2e",
                                 fg="#e6e6e6")
        tagline_label.pack(pady=(0, 40))

        # Content frame - split into two columns
        content_frame = tk.Frame(main_frame, bg="#1a1a2e")
        content_frame.pack(fill="both", expand=True)

        ############################################## Left column - Image
        left_column = tk.Frame(content_frame, bg="#1a1a2e", width=500)
        left_column.pack(side="left", fill="both", expand=True, padx=(0, 20))

        # Try to load an image if it exists
        image_paths = [
            "logo.png", "image.png", "placeholder.jpg",
            "isharay_logo.png", "sign_language.jpg"
        ]

        image_loaded = False
        for img_path in image_paths:
            if os.path.exists(img_path):
                try:
                    # Load and resize image
                    pil_image = Image.open(img_path)
                    # Resize to fit the frame (adjust as needed)
                    pil_image = pil_image.resize((630, 570), Image.Resampling.LANCZOS)
                    image_tk = ImageTk.PhotoImage(pil_image)

                    image_label = tk.Label(left_column, image=image_tk, bg="#1a1a2e")
                    image_label.image = image_tk  # Keep a reference
                    image_label.pack(fill="both", expand=True, pady=5)
                    image_loaded = True
                    break
                except Exception as e:
                    print(f"Could not load image {img_path}: {e}")

        if not image_loaded:
            # Create a placeholder with app info
            placeholder_frame = tk.Frame(left_column, bg="#16213e", relief="raised", bd=2)
            placeholder_frame.pack(fill="both", expand=True, pady=20)





        # Right column - Options
        right_column = tk.Frame(content_frame, bg="#1a1a2e", width=500)
        right_column.pack(side="right", fill="both", expand=True)

        # Options frame
        options_frame = tk.Frame(right_column, bg="#1a1a2e")
        options_frame.pack(fill="both", expand=True, pady=20)

        # Option 1: Text to Sign Language
        option1_frame = tk.Frame(options_frame, bg="#16213e", relief="raised", bd=2)
        option1_frame.pack(fill="x", pady=15, padx=50)

        option1_label = tk.Label(option1_frame,
                                 text="📝 Text to Sign Language",
                                 font=("Arial", 16, "bold"),
                                 bg="#16213e",
                                 fg="#e6e6e6",
                                 justify="center",
                                 padx=20,
                                 pady=20)
        option1_label.pack()

        # Option 2: Sign Language Detection
        option2_frame = tk.Frame(options_frame, bg="#16213e", relief="raised", bd=2)
        option2_frame.pack(fill="x", pady=15, padx=50)

        option2_label = tk.Label(option2_frame,
                                 text="🎥 Sign Language Detection\nAlphabet/Word Recognition",
                                 font=("Arial", 16, "bold"),
                                 bg="#16213e",
                                 fg="#e6e6e6",
                                 justify="center",
                                 padx=20,
                                 pady=20)
        option2_label.pack()

        # Option 3: About Us
        option3_frame = tk.Frame(options_frame, bg="#16213e", relief="raised", bd=2)
        option3_frame.pack(fill="x", pady=15, padx=50)

        option3_label = tk.Label(option3_frame,
                                 text="About Us",
                                 font=("Arial", 16, "bold"),
                                 bg="#16213e",
                                 fg="#e6e6e6",
                                 justify="center",
                                 padx=20,
                                 pady=20)
        option3_label.pack()

        # Make options clickable
        for frame, label, command in [
            (option1_frame, option1_label, self.open_text_to_sign_app),
            (option2_frame, option2_label, self.open_detection_app),
            (option3_frame, option3_label, self.open_about_us)
        ]:
            frame.bind("<Button-1>", lambda e, cmd=command: cmd())
            label.bind("<Button-1>", lambda e, cmd=command: cmd())
            frame.configure(cursor="hand2")
            label.configure(cursor="hand2")

        # Add hover effects
        def on_enter(e):
            e.widget.configure(bg="#0f3460")

        def on_leave(e):
            e.widget.configure(bg="#16213e")

        for widget in [option1_frame, option2_frame, option3_frame,
                       option1_label, option2_label, option3_label]:
            widget.bind("<Enter>", on_enter)
            widget.bind("<Leave>", on_leave)

        # Footer
        footer_frame = tk.Frame(main_frame, bg="#1a1a2e")
        footer_frame.pack(side="bottom", fill="x", pady=(20, 0))

        copyright_label = tk.Label(footer_frame,
                                   text="© 2024 ISHARAY - All Rights Reserved",
                                   font=("Arial", 10),
                                   bg="#1a1a2e",
                                   fg="#7f8c8d")
        copyright_label.pack()

    def open_text_to_sign_app(self):
        # Clear landing page and open text-to-sign app
        for widget in self.root.winfo_children():
            widget.destroy()
        TextToSignApp(self.root, self.backend)

    def open_detection_app(self):
        # Clear landing page and open detection app
        for widget in self.root.winfo_children():
            widget.destroy()
        SignLanguageApp(self.root, self.backend)

    def open_about_us(self):
        # Clear landing page and open about us page
        for widget in self.root.winfo_children():
            widget.destroy()
        AboutUsPage(self.root, self.backend)


class AboutUsPage:
    def __init__(self, root, backend=None):
        self.root = root
        self.backend = backend
        self.root.title("ISHARAY - About Us")
        self.root.geometry("1200x800")
        self.root.configure(bg="#1a1a2e")

        self.setup_scrollable_page()

    def setup_scrollable_page(self):
        # 1. Create a Main Container for Canvas and Scrollbar
        main_container = tk.Frame(self.root, bg="#1a1a2e")
        main_container.pack(fill="both", expand=True)

        # 2. Create Canvas
        self.canvas = tk.Canvas(main_container, bg="#1a1a2e", highlightthickness=0)
        self.canvas.pack(side="left", fill="both", expand=True)

        # 3. Add Scrollbar
        scrollbar = tk.Scrollbar(main_container, orient="vertical", command=self.canvas.yview)
        scrollbar.pack(side="right", fill="y")
        self.canvas.configure(yscrollcommand=scrollbar.set)

        # 4. Create the Scrollable Frame (Holds all content)
        self.scroll_frame = tk.Frame(self.canvas, bg="#1a1a2e")

        # Create a window inside the canvas
        self.canvas_window = self.canvas.create_window((0, 0), window=self.scroll_frame, anchor="nw")

        # 5. Bind events to update scroll region
        self.scroll_frame.bind("<Configure>", self.on_frame_configure)
        self.canvas.bind("<Configure>", self.on_canvas_configure)

        # Bind Mousewheel for scrolling
        self.root.bind_all("<MouseWheel>", self.on_mousewheel)

        # 6. Build the actual content inside scroll_frame
        self.setup_content(self.scroll_frame)

    def on_frame_configure(self, event):
        """Reset the scroll region to encompass the inner frame"""
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def on_canvas_configure(self, event):
        """When canvas resizes, resize the inner frame to match width"""
        self.canvas.itemconfig(self.canvas_window, width=event.width)

    def on_mousewheel(self, event):
        """Enable mousewheel scrolling"""
        self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    def setup_content(self, parent):
        # --- ORIGINAL CONTENT LOGIC (With Fixes) ---

        # Add padding wrapper inside the scroll frame
        content_wrapper = tk.Frame(parent, bg="#1a1a2e")
        content_wrapper.pack(fill="both", expand=True, padx=50, pady=50)

        # Header
        header_frame = tk.Frame(content_wrapper, bg="#1a1a2e")
        header_frame.pack(fill="x", pady=(0, 40))

        # Back button
        back_button = tk.Button(header_frame, text="← Back to Home",
                                font=("Arial", 12),
                                command=self.back_to_home,
                                bg="#3498db", fg="white",
                                relief="flat", padx=15, pady=5)
        back_button.pack(side="left")

        # Hover effects
        def on_enter(e): back_button.configure(bg="#2980b9")

        def on_leave(e): back_button.configure(bg="#3498db")

        back_button.bind("<Enter>", on_enter)
        back_button.bind("<Leave>", on_leave)

        # Title
        title_label = tk.Label(header_frame,
                               text="About ISHARAY",
                               font=("Arial", 32, "bold"),
                               bg="#1a1a2e",
                               fg="#4cc9f0")
        title_label.pack(side="right")

        # --- SECTIONS ---
        # Note: 'expand=True' removed from these sections so they take natural height
        # instead of forcing themselves to fit in limited screen space.

        # Mission section
        mission_frame = tk.Frame(content_wrapper, bg="#16213e", relief="raised", bd=2)
        mission_frame.pack(fill="x", pady=(0, 30))  # Changed to fill="x"

        mission_title = tk.Label(mission_frame,
                                 text="Our Mission",
                                 font=("Arial", 24, "bold"),
                                 bg="#16213e",
                                 fg="#4cc9f0",
                                 pady=20)
        mission_title.pack()

        mission_text = """At ISHARAY, we believe communication is a fundamental human right. 
Our mission is to bridge the communication gap between the hearing 
and Deaf communities in Bangladesh by providing innovative, accessible, 
and accurate Bangla Sign Language technology.

We envision a world where everyone can communicate freely, 
regardless of their hearing ability."""

        mission_content = tk.Label(mission_frame,
                                   text=mission_text,
                                   font=("Arial", 14),
                                   bg="#16213e",
                                   fg="#e6e6e6",
                                   justify="center",
                                   wraplength=800,
                                   pady=20)
        mission_content.pack()

        # Features section
        features_frame = tk.Frame(content_wrapper, bg="#1a1a2e")
        features_frame.pack(fill="x", pady=10)  # Changed to fill="x"

        features_title = tk.Label(features_frame,
                                  text="What We Offer",
                                  font=("Arial", 24, "bold"),
                                  bg="#1a1a2e",
                                  fg="#4cc9f0",
                                  pady=20)
        features_title.pack()

        # Feature cards container
        features_container = tk.Frame(features_frame, bg="#1a1a2e")
        features_container.pack(fill="x", pady=20)

        features = [
            {
                "title": "📝 Text to Sign Language",
                "desc": "Convert Bangla text into sign language videos automatically. Build sentences using our word bank and create seamless sign language communication."
            },
            {
                "title": "🎥 Real-time Sign Detection",
                "desc": "Use your webcam to detect and interpret Bangla Sign Language in real-time. Supports both alphabets and common words with high accuracy."
            },
            {
                "title": "🎓 Learning Resources",
                "desc": "Access our comprehensive database of Bangla Sign Language signs. Perfect for learners, educators, and anyone interested in BDSL."
            },
            {
                "title": "🔧 User-Friendly Interface",
                "desc": "Designed with accessibility in mind. Simple, intuitive controls make ISHARAY easy to use for everyone."
            }
        ]

        # Config grid weights
        features_container.grid_columnconfigure(0, weight=1)
        features_container.grid_columnconfigure(1, weight=1)

        for i, feature in enumerate(features):
            # Card Frame
            feature_frame = tk.Frame(features_container, bg="#16213e", relief="raised", bd=1)
            feature_frame.grid(row=i // 2, column=i % 2, padx=20, pady=10, sticky="nsew")

            feature_label = tk.Label(feature_frame,
                                     text=feature["title"],
                                     font=("Arial", 16, "bold"),
                                     bg="#16213e",
                                     fg="#4cc9f0",
                                     pady=15)
            feature_label.pack(fill="x")

            feature_desc = tk.Label(feature_frame,
                                    text=feature["desc"],
                                    font=("Arial", 12),
                                    bg="#16213e",
                                    fg="#e6e6e6",
                                    wraplength=400,  # Increased wraplength slightly
                                    justify="center",
                                    padx=20,
                                    pady=15)
            feature_desc.pack(fill="both", expand=True)

        # Team/Values section
        values_frame = tk.Frame(content_wrapper, bg="#16213e", relief="raised", bd=2)
        values_frame.pack(fill="x", pady=30)

        values_title = tk.Label(values_frame,
                                text="Our Values",
                                font=("Arial", 24, "bold"),
                                bg="#16213e",
                                fg="#4cc9f0",
                                pady=20)
        values_title.pack()

        values_text = """• Accessibility: Making communication technology available to all
• Accuracy: Ensuring precise sign language recognition and generation
• Innovation: Continuously improving our technology and features
• Inclusivity: Creating tools that serve both Deaf and hearing communities
• Education: Promoting Bangla Sign Language learning and awareness"""

        values_content = tk.Label(values_frame,
                                  text=values_text,
                                  font=("Arial", 14),
                                  bg="#16213e",
                                  fg="#e6e6e6",
                                  justify="left",
                                  padx=40,
                                  pady=20)
        values_content.pack()

        # Contact/Footer
        footer_frame = tk.Frame(content_wrapper, bg="#1a1a2e")
        footer_frame.pack(side="bottom", fill="x", pady=(20, 0))

        contact_text = """Contact Us: support@isharay.com |
© 2025 ISHARAY Project - Bridging Voices and Signs in Bangla"""

        footer_label = tk.Label(footer_frame,
                                text=contact_text,
                                font=("Arial", 11),
                                bg="#1a1a2e",
                                fg="#7f8c8d")
        footer_label.pack()

    def back_to_home(self):
        # Unbind global mousewheel to prevent errors on other pages
        self.root.unbind_all("<MouseWheel>")

        for widget in self.root.winfo_children():
            widget.destroy()


        LandingPage(self.root, self.backend)



class TextToSignApp:
    def __init__(self, root, backend):
        self.root = root
        self.backend = backend
        self.root.title("ISHARAY - Text to Sign Language")
        self.root.geometry("1200x700")
        self.root.configure(bg="#f0f0f0")

        self.processing = False
        self.video_playing = False
        self.video_cap = None
        self.video_thread = None

        self.setup_ui()

    def setup_ui(self):
        # Main container
        main_container = tk.Frame(self.root, bg="#f0f0f0")
        main_container.pack(fill="both", expand=True, padx=20, pady=20)

        # Left panel - Input and controls
        left_panel = tk.Frame(main_container, bg="white", width=500, height=600)
        left_panel.pack(side="left", fill="both", expand=True, padx=(0, 20))
        left_panel.pack_propagate(False)

        # Title and back button
        title_frame = tk.Frame(left_panel, bg="white")
        title_frame.pack(fill="x", padx=20, pady=20)

        # Back button
        back_btn = tk.Button(title_frame, text="← Back", font=("Arial", 11),
                             command=self.back_to_home,
                             bg="#95a5a6", fg="white", height=1, width=8)
        back_btn.pack(side="left")

        tk.Label(title_frame, text="Text to Sign Language", font=("Arial", 18, "bold"),
                 bg="white", fg="#2c3e50").pack(side="left", padx=(20, 0))

        # Instructions
        instruction_frame = tk.Frame(left_panel, bg="white")
        instruction_frame.pack(fill="x", padx=20, pady=(0, 20))

        tk.Label(instruction_frame, text="Enter Bangla text below:", font=("Arial", 12),
                 bg="white", fg="#34495e").pack(anchor="w", pady=(0, 10))

        tk.Label(instruction_frame, text="Tip: Click on any word below to add it to the text input",
                 font=("Arial", 10), bg="white", fg="#7f8c8d").pack(anchor="w", pady=(0, 5))

        # Available words list
        available_frame = tk.Frame(left_panel, bg="white")
        available_frame.pack(fill="x", padx=20, pady=(0, 20))

        tk.Label(available_frame, text="Available Words:", font=("Arial", 12, "bold"),
                 bg="white", fg="#34495e").pack(anchor="w", pady=(0, 10))

        # Create a scrolled frame for available words
        words_frame = tk.Frame(available_frame, bg="white")
        words_frame.pack(fill="x")

        # Create a canvas for scrolling
        canvas = tk.Canvas(words_frame, bg="white", height=100)
        scrollbar = tk.Scrollbar(words_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg="white")

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Add available words as clickable labels
        self.word_labels = []
        row = 0
        col = 0
        available_words = self.backend.get_available_words()
        for word in available_words:
            word_label = tk.Label(scrollable_frame, text=word, font=("Arial", 10),
                                  bg="#ecf0f1", fg="#2c3e50", relief="raised", padx=5, pady=2,
                                  cursor="hand2")
            word_label.grid(row=row, column=col, padx=2, pady=2, sticky="w")
            word_label.bind("<Button-1>", lambda e, w=word: self.add_word_to_input(w))

            # Hover effects
            word_label.bind("<Enter>", lambda e, lbl=word_label:
            lbl.configure(bg="#3498db", fg="white"))
            word_label.bind("<Leave>", lambda e, lbl=word_label:
            lbl.configure(bg="#ecf0f1", fg="#2c3e50"))

            self.word_labels.append(word_label)
            col += 1
            if col > 3:
                col = 0
                row += 1

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Text input area
        input_frame = tk.Frame(left_panel, bg="white")
        input_frame.pack(fill="both", expand=True, padx=20, pady=(0, 20))

        # Input text label with clear button
        input_label_frame = tk.Frame(input_frame, bg="white")
        input_label_frame.pack(fill="x", pady=(0, 5))

        tk.Label(input_label_frame, text="Input Text:", font=("Arial", 12, "bold"),
                 bg="white", fg="#34495e").pack(side="left")

        # Clear button
        clear_btn = tk.Button(input_label_frame, text="Clear", font=("Arial", 9),
                              command=self.clear_input_text,
                              bg="#e74c3c", fg="white", height=1, width=6)
        clear_btn.pack(side="right", padx=(5, 0))

        # Add space button
        space_btn = tk.Button(input_label_frame, text="Add Space", font=("Arial", 9),
                              command=lambda: self.add_word_to_input(" "),
                              bg="#95a5a6", fg="white", height=1, width=8)
        space_btn.pack(side="right", padx=(5, 0))

        self.text_input = scrolledtext.ScrolledText(input_frame, font=("Arial", 12),
                                                    height=8, wrap=tk.WORD, bg="#f8f9fa")
        self.text_input.pack(fill="both", expand=True)
        self.text_input.bind("<Control-a>", self.select_all_text)
        self.text_input.bind("<Control-A>", self.select_all_text)
        self.text_input.insert("1.0", "উদাহরণ: আমার নাম")

        # Controls
        controls_frame = tk.Frame(left_panel, bg="white")
        controls_frame.pack(fill="x", padx=20, pady=(0, 20))

        self.btn_generate = tk.Button(controls_frame, text="Generate Sign Video", font=("Arial", 12),
                                      command=self.generate_video,
                                      bg="#27ae60", fg="white", height=1, width=18)
        self.btn_generate.pack(side="left", padx=(0, 10))

        self.btn_play = tk.Button(controls_frame, text="▶ Play Video", font=("Arial", 12),
                                  command=self.toggle_video_playback,
                                  bg="#3498db", fg="white", height=1, width=12, state="disabled")
        self.btn_play.pack(side="left", padx=(0, 10))

        # Status area
        status_frame = tk.Frame(left_panel, bg="white")
        status_frame.pack(fill="x", padx=20, pady=(0, 20))

        tk.Label(status_frame, text="Status:", font=("Arial", 12, "bold"),
                 bg="white", fg="#34495e").pack(anchor="w", pady=(0, 5))

        self.status_text = scrolledtext.ScrolledText(status_frame, font=("Arial", 10),
                                                     height=6, wrap=tk.WORD, bg="#f8f9fa")
        self.status_text.pack(fill="both", expand=True)
        self.status_text.configure(state="disabled")

        # Right panel - Video preview
        right_panel = tk.Frame(main_container, bg="#2c3e50", width=500, height=600)
        right_panel.pack(side="right", fill="both", expand=True)
        right_panel.pack_propagate(False)

        # Video preview title
        video_title_frame = tk.Frame(right_panel, bg="#2c3e50")
        video_title_frame.pack(fill="x", padx=20, pady=20)

        tk.Label(video_title_frame, text="Video Preview", font=("Arial", 18, "bold"),
                 bg="#2c3e50", fg="white").pack(anchor="w")

        # Video display area
        self.video_frame = tk.Label(right_panel, bg="black", text="Video will appear here\n\n"
                                                                  "Generate video first, then click 'Play Video'\n\n"
                                                                  "Tip: Click on words above to build your text",
                                    font=("Arial", 14), fg="white", justify="center")
        self.video_frame.pack(fill="both", expand=True, padx=20, pady=20)



    def add_word_to_input(self, word):
        cursor_pos = self.text_input.index(tk.INSERT)
        current_text = self.text_input.get("1.0", tk.END).strip()

        if word == " ":
            self.text_input.insert(cursor_pos, " ")
        else:
            if current_text and cursor_pos != "1.0":
                prev_char = self.text_input.get(f"{cursor_pos} - 1c", cursor_pos)
                if prev_char and prev_char != " ":
                    word = " " + word
            self.text_input.insert(cursor_pos, word)
            self.text_input.insert(f"{cursor_pos} + {len(word)}c", " ")

        self.text_input.focus_set()

    def clear_input_text(self):
        self.text_input.delete("1.0", tk.END)
        self.text_input.focus_set()

    def select_all_text(self, event=None):
        self.text_input.tag_add(tk.SEL, "1.0", tk.END)
        return "break"

    def log_status(self, message):
        self.status_text.configure(state="normal")
        self.status_text.insert(tk.END, message + "\n")
        self.status_text.see(tk.END)
        self.status_text.configure(state="disabled")
        self.root.update()

    def generate_video(self):
        if self.processing:
            return

        text = self.text_input.get("1.0", tk.END).strip()
        if not text:
            messagebox.showwarning("Input Required", "Please enter some Bangla text.")
            return

        self.processing = True
        self.btn_generate.config(state="disabled", text="Processing...")
        self.btn_play.config(state="disabled")
        self.video_frame.config(text="Generating video...\nPlease wait")
        self.log_status(f"Starting video generation for text: '{text}'")

        thread = threading.Thread(target=self._generate_video_thread, args=(text,))
        thread.start()

    def _generate_video_thread(self, text):
        def progress_callback(message):
            self.root.after(0, self.log_status, message)

        success, status_messages, output_file = self.backend.generate_sign_video(text, progress_callback)
        self.root.after(0, self._generation_complete, success, output_file)

    def _generation_complete(self, success, output_file):
        self.processing = False
        self.btn_generate.config(state="normal", text="Generate Sign Video")

        if success:
            self.btn_play.config(state="normal", text="▶ Play Video")
            self.video_frame.config(text="Video generated successfully!\n\n"
                                         f"File: {output_file}\n\n"
                                         "Click 'Play Video' to view")
            messagebox.showinfo("Success", f"Video generated successfully!\n\nSaved as: {output_file}")
        else:
            self.video_frame.config(text="Video generation failed\n\n"
                                         "Check status for details")
            messagebox.showerror("Generation Failed", "Failed to generate video. Check status for details.")

    def toggle_video_playback(self):
        if not self.backend.check_video_file(OUTPUT_FILE):
            messagebox.showwarning("File Not Found", "No video file found. Please generate a video first.")
            return

        if self.video_playing:
            self.stop_video_playback()
        else:
            self.start_video_playback()

    def start_video_playback(self):
        try:
            self.video_cap = self.backend.get_video_capture(OUTPUT_FILE)
            if self.video_cap is None or not self.video_cap.isOpened():
                messagebox.showerror("Playback Error", "Could not open video file.")
                return

            self.video_playing = True
            self.btn_play.config(text="⏸ Stop Video", bg="#e74c3c")
            self.video_frame.config(text="Playing video...")

            self.video_thread = threading.Thread(target=self._play_video_thread)
            self.video_thread.daemon = True
            self.video_thread.start()

            self.log_status(f"\n▶️ Playing video in UI: {OUTPUT_FILE}")

        except Exception as e:
            error_msg = f"Error starting video playback: {str(e)}"
            self.log_status(f"\n❌ ERROR: {error_msg}")
            messagebox.showerror("Playback Error", error_msg)

    def _play_video_thread(self):
        try:
            fps = self.video_cap.get(cv2.CAP_PROP_FPS)
            frame_delay = int(1000 / fps) if fps > 0 else 30

            while self.video_playing:
                ret, frame = self.video_cap.read()
                if not ret:
                    self.video_cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                    continue

                frame_height, frame_width = frame.shape[:2]
                label_width = self.video_frame.winfo_width()
                label_height = self.video_frame.winfo_height()

                if label_width > 1 and label_height > 1:
                    aspect_ratio = frame_width / frame_height
                    if label_width / label_height > aspect_ratio:
                        new_height = label_height
                        new_width = int(new_height * aspect_ratio)
                    else:
                        new_width = label_width
                        new_height = int(new_width / aspect_ratio)

                    if new_width > 0 and new_height > 0:
                        frame = cv2.resize(frame, (new_width, new_height))

                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                img = Image.fromarray(frame_rgb)
                imgtk = ImageTk.PhotoImage(image=img)
                self.root.after(0, self._update_video_frame, imgtk)
                cv2.waitKey(frame_delay)

        except Exception as e:
            print(f"Video playback error: {e}")
        finally:
            if self.video_cap:
                self.video_cap.release()
            self.root.after(0, self._video_playback_stopped)

    def _update_video_frame(self, imgtk):
        try:
            self.video_frame.imgtk = imgtk
            self.video_frame.configure(image=imgtk)
        except:
            pass

    def _video_playback_stopped(self):
        self.video_playing = False
        self.btn_play.config(text="▶ Play Video", bg="#3498db")
        self.video_frame.config(text="Video playback stopped\n\n"
                                     "Click 'Play Video' to play again")

    def stop_video_playback(self):
        self.video_playing = False
        if self.video_cap:
            self.video_cap.release()
            self.video_cap = None

        self.btn_play.config(text="▶ Play Video", bg="#3498db")
        self.video_frame.config(text="Video playback stopped\n\n"
                                     "Click 'Play Video' to play again")
        self.log_status("\n⏸ Video playback stopped")

    def back_to_home(self):
        if self.video_playing:
            self.stop_video_playback()

        for widget in self.root.winfo_children():
            widget.destroy()
        LandingPage(self.root, self.backend)


class SignLanguageApp:
    def __init__(self, root, backend):
        self.root = root
        self.backend = backend
        self.root.title("BdSL Detection System")
        self.root.geometry("1200x700")
        self.root.configure(bg="#f0f0f0")

        self.camera_running = True
        self.current_detection = "No detection"
        self.current_confidence = 0.0
        self.top_predictions = []

        self.backend.initialize_camera()
        self.setup_ui()
        self.video_loop()

    def setup_ui(self):
        # Main container
        main_container = tk.Frame(self.root, bg="#f0f0f0")
        main_container.pack(fill="both", expand=True, padx=20, pady=20)

        # Left panel - Video feed
        left_panel = tk.Frame(main_container, bg="#2c3e50", width=800, height=600)
        left_panel.pack(side="left", fill="both", expand=True, padx=(0, 20))
        left_panel.pack_propagate(False)

        # Video frame
        self.video_frame = tk.Label(left_panel, bg="#2c3e50")
        self.video_frame.pack(fill="both", expand=True, padx=10, pady=10)

        # Right panel - Controls and info
        right_panel = tk.Frame(main_container, bg="white", width=300, height=600)
        right_panel.pack(side="right", fill="y")
        right_panel.pack_propagate(False)

        # Title and back button
        title_frame = tk.Frame(right_panel, bg="white")
        title_frame.pack(fill="x", padx=20, pady=20)

        # Back button
        back_btn = tk.Button(title_frame, text="← Back", font=("Arial", 11),
                             command=self.back_to_home,
                             bg="#95a5a6", fg="white", height=1, width=8)
        back_btn.pack(side="left")

        tk.Label(title_frame, text="Live Feed", font=("Arial", 18, "bold"),
                 bg="white", fg="#2c3e50").pack(side="left", padx=(20, 0))

        # Mode selection
        mode_frame = tk.Frame(right_panel, bg="white")
        mode_frame.pack(fill="x", padx=20, pady=(0, 20))

        tk.Label(mode_frame, text="Detection Mode", font=("Arial", 12, "bold"),
                 bg="white", fg="#34495e").pack(anchor="w", pady=(0, 10))

        mode_btn_frame = tk.Frame(mode_frame, bg="white")
        mode_btn_frame.pack(fill="x")

        self.btn_word = tk.Button(mode_btn_frame, text="Words", font=("Arial", 11),
                                  command=lambda: self.set_mode("word"),
                                  bg="#27ae60", fg="white", height=1, width=8)
        self.btn_word.pack(side="left", padx=(0, 5))

        self.btn_alpha = tk.Button(mode_btn_frame, text="Alphabets", font=("Arial", 11),
                                   command=lambda: self.set_mode("alpha"),
                                   bg="#95a5a6", fg="white", height=1, width=8)
        self.btn_alpha.pack(side="left")

        # Controls section
        controls_frame = tk.Frame(right_panel, bg="white")
        controls_frame.pack(fill="x", padx=20, pady=(0, 20))

        tk.Label(controls_frame, text="Controls", font=("Arial", 12, "bold"),
                 bg="white", fg="#34495e").pack(anchor="w", pady=(0, 10))

        self.btn_start = tk.Button(controls_frame, text="Start Camera", font=("Arial", 11),
                                   command=self.start_camera,
                                   bg="#3498db", fg="white", height=1, width=12)
        self.btn_start.pack(fill="x", pady=2)

        self.btn_stop = tk.Button(controls_frame, text="Stop Camera", font=("Arial", 11),
                                  command=self.stop_camera,
                                  bg="#e74c3c", fg="white", height=1, width=12)
        self.btn_stop.pack(fill="x", pady=2)

        # Current detection section
        detection_frame = tk.Frame(right_panel, bg="white")
        detection_frame.pack(fill="x", padx=20, pady=(0, 20))

        tk.Label(detection_frame, text="Current Detection", font=("Arial", 12, "bold"),
                 bg="white", fg="#34495e").pack(anchor="w", pady=(0, 10))

        # Confidence display
        confidence_frame = tk.Frame(detection_frame, bg="white")
        confidence_frame.pack(fill="x", pady=(0, 10))

        tk.Label(confidence_frame, text="Confidence", font=("Arial", 10),
                 bg="white", fg="#7f8c8d").pack(anchor="w")

        self.confidence_var = tk.StringVar(value="0.0%")
        tk.Label(confidence_frame, textvariable=self.confidence_var, font=("Arial", 16, "bold"),
                 bg="white", fg="#27ae60").pack(anchor="w")

        # Detection result
        self.detection_var = tk.StringVar(value="No detection")
        tk.Label(detection_frame, textvariable=self.detection_var, font=("Arial", 14, "bold"),
                 bg="white", fg="#2c3e50", wraplength=250).pack(anchor="w", pady=(5, 0))

        # Distribution section
        distribution_frame = tk.Frame(right_panel, bg="white")
        distribution_frame.pack(fill="x", padx=20, pady=(0, 20))

        tk.Label(distribution_frame, text="Distribution", font=("Arial", 12, "bold"),
                 bg="white", fg="#34495e").pack(anchor="w", pady=(0, 10))

        self.distribution_labels = []
        for i in range(3):
            label_frame = tk.Frame(distribution_frame, bg="white")
            label_frame.pack(fill="x", pady=2)

            checkbox = tk.Label(label_frame, text="☑️", font=("Arial", 10), bg="white", fg="#27ae60")
            checkbox.pack(side="left")

            dist_label = tk.Label(label_frame, text="0%", font=("Arial", 10),
                                  bg="white", fg="#2c3e50")
            dist_label.pack(side="left", padx=(5, 0))
            self.distribution_labels.append(dist_label)

    # ... (rest of the SignLanguageApp methods remain the same)
    # [Keep all the existing methods: set_mode, start_camera, stop_camera,
    # update_display, get_font, video_loop, back_to_home]

    def set_mode(self, mode):
        self.backend.set_mode(mode)
        self.current_detection = "No detection"
        self.current_confidence = 0.0
        self.top_predictions = []
        self.update_display()

        if mode == "word":
            self.btn_word.config(bg="#27ae60", fg="white")
            self.btn_alpha.config(bg="#95a5a6", fg="white")
        else:
            self.btn_word.config(bg="#95a5a6", fg="white")
            self.btn_alpha.config(bg="#2980b9", fg="white")

    def start_camera(self):
        self.camera_running = True
        self.backend.initialize_camera()

    def stop_camera(self):
        self.camera_running = False

    def update_display(self):
        self.confidence_var.set(f"{self.current_confidence:.1f}%")
        self.detection_var.set(self.current_detection)

        for i, label in enumerate(self.distribution_labels):
            if i < len(self.top_predictions):
                pred_text, confidence = self.top_predictions[i]
                label.config(text=f"{pred_text} {confidence:.1f}%")
            else:
                label.config(text="")

    def get_font(self, size):
        try:
            from backend import FONT_NAME
            return ImageFont.truetype(FONT_NAME, size, layout_engine=ImageFont.LAYOUT_RAQM)
        except:
            return ImageFont.load_default()

    def video_loop(self):
        if self.camera_running:
            ret, frame = self.backend.get_camera_frame()
            if ret:
                processed_frame, overlay_text, confidence, top_predictions, detection = self.backend.process_frame(
                    frame)

                self.current_detection = detection
                self.current_confidence = confidence
                self.top_predictions = top_predictions
                self.update_display()

                if processed_frame is not None:
                    # Create overlay on frame
                    img_pil = Image.fromarray(processed_frame)
                    draw = ImageDraw.Draw(img_pil)

                    # Draw mode indicator
                    color = (46, 204, 113) if self.backend.mode == "word" else (52, 152, 219)
                    draw.rectangle([(10, 10), (200, 50)], fill=color)
                    font = self.get_font(20)
                    draw.text((20, 15), f"MODE: {self.backend.mode.upper()}", font=font, fill="white")

                    # Draw detection text
                    font_large = self.get_font(28)
                    text_bbox = draw.textbbox((0, 0), overlay_text, font=font_large)
                    text_width = text_bbox[2] - text_bbox[0]
                    frame_height, frame_width = processed_frame.shape[:2]
                    draw.text((frame_width // 2 - text_width // 2, frame_height - 100),
                              overlay_text, font=font_large, fill=(255, 255, 255),
                              stroke_width=2, stroke_fill=(0, 0, 0))

                    img_tk = ImageTk.PhotoImage(image=img_pil)
                    self.video_frame.imgtk = img_tk
                    self.video_frame.configure(image=img_tk)
            else:
                # No frame - show black screen
                blank_image = Image.new('RGB', (640, 480), (0, 0, 0))
                img_tk = ImageTk.PhotoImage(image=blank_image)
                self.video_frame.imgtk = img_tk
                self.video_frame.configure(image=img_tk)

        self.root.after(10, self.video_loop)

    def back_to_home(self):
        self.backend.release_camera()
        cv2.destroyAllWindows()

        for widget in self.root.winfo_children():
            widget.destroy()
        LandingPage(self.root, self.backend)