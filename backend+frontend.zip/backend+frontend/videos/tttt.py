import os
import time
import speech_recognition as sr
from moviepy.editor import VideoFileClip
import nltk
from nltk.tokenize import word_tokenize

# First time only: download punkt tokenizer
nltk.download('punkt')

# ---------- CONFIG ----------

VIDEO_FOLDER = "sign_videos"             # folder where your sign videos are stored
VIDEO_EXTENSIONS = [".mp4", ".mkv", ".avi", ".mov"]  # allowed video types

# Optional: simple lemma mapping (you can extend this)
LEMMA_MAP = {
    # "খাচ্ছি": "খাওয়া",
    # "খাই": "খাওয়া",
    # ...
    # Add your own mappings here if needed
}

# ----------------------------

def lemmatize_token(token: str) -> str:
    """Return lemma/root of the word if in map, else the word itself."""
    return LEMMA_MAP.get(token, token)


def normalize_bangla_text(text: str) -> str:
    """Basic normalization – you can add more rules."""
    text = text.strip()
    return text


def tokenize_bangla_text(text: str):
    """Tokenize Bangla text into words."""
    tokens = word_tokenize(text)
    print("Tokens:", tokens)
    return tokens


def find_video_for_word(word: str) -> str | None:
    """
    Search VIDEO_FOLDER for a file whose name matches the word (without extension).
    e.g. word 'ami' -> ami.mp4
    """
    for file_name in os.listdir(VIDEO_FOLDER):
        name, ext = os.path.splitext(file_name)
        if ext.lower() in VIDEO_EXTENSIONS and name == word:
            return os.path.join(VIDEO_FOLDER, file_name)
    return None


def play_video(video_path: str):
    """
    Play a video file using moviepy.
    Audio is muted to avoid feedback into microphone.
    """
    print(f"Playing: {video_path}")
    clip = VideoFileClip(video_path).without_audio()
    clip.preview()   # opens a window and plays the video
    clip.close()


def recognize_chunk(recognizer: sr.Recognizer, audio_data: sr.AudioData) -> str:
    """
    Recognize Bangla speech from audio chunk using Google Web Speech API.
    """
    try:
        text = recognizer.recognize_google(audio_data, language="bn-BD")
        print("\nRecognized:", text)
        return text
    except sr.UnknownValueError:
        print("\nCould not understand audio")
    except sr.RequestError as e:
        print(f"\nAPI error: {e}")
    return ""


def process_text_to_sign(text: str):
    """
    Full text -> tokens -> lemmas -> play corresponding sign videos.
    """
    if not text:
        return

    # 1. Normalize
    text = normalize_bangla_text(text)

    # 2. Tokenize
    tokens = tokenize_bangla_text(text)

    # 3. Lemmatize (optional, if you filled LEMMA_MAP)
    lemma_tokens = [lemmatize_token(t) for t in tokens]
    print("Lemma tokens:", lemma_tokens)

    # 4. For each token, play video if exists
    for token in lemma_tokens:
        # Skip punctuation / numbers
        if not any(ch.isalpha() for ch in token):
            continue

        # If your videos are named in Bangla script, token should be Bangla too.
        # If videos are transliteration (ami/tumi), you need a mapping here.

        video_path = find_video_for_word(token)
        if video_path:
            play_video(video_path)
            time.sleep(0.3)   # small gap between videos
        else:
            print(f"No video found for word: {token}")


def main():
    recognizer = sr.Recognizer()

    # Use default system microphone
    with sr.Microphone() as source:
        print("Adjusting for background noise... Please stay quiet.")
        recognizer.adjust_for_ambient_noise(source, duration=2)
        print("Done. You can start speaking.")

        print("\n---- REALTIME BANGLA → SIGN ----")
        print("Speak in short phrases (2-3 seconds).")
        print("Press Ctrl + C in the terminal to stop.\n")

        try:
            while True:
                print("Listening...")
                # phrase_time_limit controls how long each chunk is (in seconds)
                audio_data = recognizer.listen(source, phrase_time_limit=3)

                print("Processing...")
                text = recognize_chunk(recognizer, audio_data)

                # Optional: stop if user says "stop" or "বন্ধ"
                if text:
                    lower_text = text.lower()
                    if "stop" in lower_text or "বন্ধ" in lower_text:
                        print("Stop word detected. Exiting.")
                        break

                # Convert to sign videos
                process_text_to_sign(text)

        except KeyboardInterrupt:
            print("\nStopped by user.")


if __name__ == "__main__":
    main()
