# main.py
import tkinter as tk
from frontend import LandingPage
from backend import BackendProcessor


def main():
    # Create the main window
    root = tk.Tk()

    # Initialize backend processor
    backend = BackendProcessor()

    # Initialize landing page
    app = LandingPage(root, backend)

    # Start the application
    root.mainloop()


if __name__ == "__main__":
    main()